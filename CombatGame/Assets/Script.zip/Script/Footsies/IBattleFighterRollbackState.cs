using UnityEngine;

public interface IBattleFighterRollbackState
{
    Vector3 RollbackPosition { get; set; }
    Vector3 RollbackVelocity { get; set; }

    // 右向き=1, 左向き=-1
    int RollbackFacingSign { get; set; }

    // 行動ID。enum を int に潰して保存
    int RollbackActionId { get; set; }

    // その行動に入ってから何フレーム目か
    int RollbackActionFrame { get; set; }

    int RollbackHP { get; set; }
    bool RollbackIsKO { get; set; }

    // あるとズレにくくなる追加情報
    bool RollbackIsGrounded { get; set; }
    int RollbackHitstunFrames { get; set; }
    int RollbackBlockstunFrames { get; set; }
    int RollbackRecoveryFrames { get; set; }
}
