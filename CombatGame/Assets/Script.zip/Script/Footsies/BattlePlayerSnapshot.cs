using System;
using UnityEngine;

[Serializable]
public struct BattlePlayerSnapshot
{
    public Vector3 position;
    public Vector3 velocity;

    public int facingSign;
    public int actionId;
    public int actionFrame;

    public int hp;
    public bool isKO;

    public bool isGrounded;
    public int hitstunFrames;
    public int blockstunFrames;
    public int recoveryFrames;
}
