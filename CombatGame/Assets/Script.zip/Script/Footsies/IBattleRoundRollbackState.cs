public interface IBattleRoundRollbackState
{
    int RollbackRoundTimerFrames { get; set; }

    bool RollbackIsRoundOver { get; set; }

    // 勝者なし = -1, P1 = 0, P2 = 1
    int RollbackWinnerPlayerId { get; set; }

    // RNG を使っているなら必須。使っていないなら 0 固定でよい
    uint RollbackRandomState { get; set; }
}
