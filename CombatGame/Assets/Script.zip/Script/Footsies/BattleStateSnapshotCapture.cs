using UnityEngine;

public static class BattleStateSnapshotCapture
{
    public static BattleStateSnapshot Capture(
        int frame,
        IBattleFighterRollbackState player1,
        IBattleFighterRollbackState player2,
        IBattleRoundRollbackState roundState)
    {
        BattleStateSnapshot snapshot = new BattleStateSnapshot
        {
            frame = frame,
            player1 = CapturePlayer(player1),
            player2 = CapturePlayer(player2),
            roundTimerFrames = roundState.RollbackRoundTimerFrames,
            isRoundOver = roundState.RollbackIsRoundOver,
            winnerPlayerId = roundState.RollbackWinnerPlayerId,
            randomState = roundState.RollbackRandomState,
            valid = true
        };

        return snapshot;
    }

    public static void Apply(
        BattleStateSnapshot snapshot,
        IBattleFighterRollbackState player1,
        IBattleFighterRollbackState player2,
        IBattleRoundRollbackState roundState)
    {
        if (!snapshot.valid)
        {
            return;
        }

        ApplyPlayer(snapshot.player1, player1);
        ApplyPlayer(snapshot.player2, player2);

        roundState.RollbackRoundTimerFrames = snapshot.roundTimerFrames;
        roundState.RollbackIsRoundOver = snapshot.isRoundOver;
        roundState.RollbackWinnerPlayerId = snapshot.winnerPlayerId;
        roundState.RollbackRandomState = snapshot.randomState;
    }

    private static BattlePlayerSnapshot CapturePlayer(IBattleFighterRollbackState player)
    {
        return new BattlePlayerSnapshot
        {
            position = player.RollbackPosition,
            velocity = player.RollbackVelocity,
            facingSign = player.RollbackFacingSign,
            actionId = player.RollbackActionId,
            actionFrame = player.RollbackActionFrame,
            hp = player.RollbackHP,
            isKO = player.RollbackIsKO,
            isGrounded = player.RollbackIsGrounded,
            hitstunFrames = player.RollbackHitstunFrames,
            blockstunFrames = player.RollbackBlockstunFrames,
            recoveryFrames = player.RollbackRecoveryFrames
        };
    }

    private static void ApplyPlayer(
        BattlePlayerSnapshot snapshot,
        IBattleFighterRollbackState player)
    {
        player.RollbackPosition = snapshot.position;
        player.RollbackVelocity = snapshot.velocity;
        player.RollbackFacingSign = snapshot.facingSign;
        player.RollbackActionId = snapshot.actionId;
        player.RollbackActionFrame = snapshot.actionFrame;
        player.RollbackHP = snapshot.hp;
        player.RollbackIsKO = snapshot.isKO;
        player.RollbackIsGrounded = snapshot.isGrounded;
        player.RollbackHitstunFrames = snapshot.hitstunFrames;
        player.RollbackBlockstunFrames = snapshot.blockstunFrames;
        player.RollbackRecoveryFrames = snapshot.recoveryFrames;
    }
}
