using System;

[Serializable]
public struct BattleStateSnapshot
{
    public int frame;

    public BattlePlayerSnapshot player1;
    public BattlePlayerSnapshot player2;

    public int roundTimerFrames;
    public bool isRoundOver;
    public int winnerPlayerId;
    public uint randomState;

    public bool valid;
}
